﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pagnozzi_Grid_Test
{
    class FileReader
    {
        #region Variables, Constructor, Accessors/Mutators
        private string _filePath;
        private List<float> gridPoints = new List<float> { };

        public FileReader(string path) { _filePath = path; }
        public string GetFilePath() { return _filePath; }
        public void SetFilePath(string path) { _filePath = path; }
        #endregion


        #region Methods

        /// <summary>
        ///  Reads Text File and parses into useable list of floats
        /// </summary>
        public List<float> ParseTextFile()
        {
            /* Parse Text File by line into Array of Tuples */
            String[] lines = File.ReadAllLines(_filePath);

            /* Decouple Tuples and append both pairs of every set to a List */
            foreach (string line in lines)
            {
                string[] tempTuple = line.Split(',');
                foreach (string point in tempTuple)
                {
                    float f1 = float.Parse(point);
                    gridPoints.Add(f1);
                }
            }

            return gridPoints;
        }
        #endregion 
    }
}

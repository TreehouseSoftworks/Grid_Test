﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pagnozzi_Grid_Test
{
    class GridController
    {

        #region Variables + Fields
        
        private List<float[]> tuples; // List of Data Sets
        
        List<float[]> row1 = new List<float[]>(); // Lists for each Row and Col
        List<float[]> row2 = new List<float[]>();
        List<float[]> row3 = new List<float[]>();
        List<float[]> col1 = new List<float[]>();
        List<float[]> col2 = new List<float[]>();
        List<float[]> col3 = new List<float[]>();

        FileReader fileReader; // FileReader Reference
        string _filePath; // string to store Path
        #endregion

        #region Private Methods

        /// <summary>
        /// Constructor that Produces the useable Data Set
        /// on Instantiation
        /// </summary>
        public GridController(string path)
        {
            _filePath = path;
            tuples = ProduceDataSet();
        }


        /// <summary>
        /// Uses the File Reader to produce a useable set of Data for
        /// us to manipulate and perform math on
        /// </summary>
        private List<float[]> ProduceDataSet()
        {
            fileReader = new FileReader(_filePath);
            List<float> gridPoints = fileReader.ParseTextFile();


            tuples = new List<float[]> { };

            for (int i = 0; i < gridPoints.Count; i += 2)
            {
                float[] tuple = new float[] { gridPoints[i], gridPoints[i + 1] };
                tuples.Add(tuple);
            }

            return tuples;
        }


        /// <summary>
        ///  Formats a float[] "tuple" into a human readable format
        /// </summary>
        /// <param name="tuple"></param>
        /// <returns></returns>
        private string FormatTuple(float[] tuple)
        {
            string formattedTuple = "(" + tuple[0] + ", " + tuple[1] + ")";
            return formattedTuple;
        }


        /// <summary>
        /// Performs an insertion sort on the provided list thats modified to handle
        /// data sets (specifically the tuples we're working with)
        /// </summary>
        /// <param name="_tuples"></param>
        /// <param name="sortByX"></param>
        /// <param name="ascending"></param>
        /// <returns></returns>
        private List<float[]> InsertionSort(List<float[]> _tuples, bool sortByX, bool ascending)
        {
            int sortedIndice = sortByX ? sortedIndice = 0 : sortedIndice = 1;

            List<float[]> clonedList = new List<float[]>(_tuples.Count);

            if (ascending)
            {
                for (int i = 0; i < _tuples.Count; i++)
                {
                    var listElement = _tuples[i];
                    var currentIndex = i;

                    while (currentIndex > 0 && clonedList[currentIndex - 1][sortedIndice] > listElement[sortedIndice])
                    {
                        currentIndex--;
                    }

                    clonedList.Insert(currentIndex, listElement);
                }
            }
            else
            {
                for (int i = 0; i < _tuples.Count; i++)
                {
                    var listElement = _tuples[i];
                    var currentIndex = i;

                    while (currentIndex > 0 && clonedList[currentIndex - 1][sortedIndice] < listElement[sortedIndice])
                    {
                        currentIndex--;
                    }

                    clonedList.Insert(currentIndex, listElement);
                }
            }

            return clonedList;
        }


        /// <summary>
        /// Sort and Display Rows
        /// </summary>
        private void DisplayRowView()
        {
            // Sort entire list of tuples by X value
            List<float[]> SortedBy_X = InsertionSort(tuples, false, false);

            // Create 3 buckets to house the rows data, sort the data by Y
            row1 = InsertionSort(SortedBy_X.GetRange(0, 3), true, true);
            row2 = InsertionSort(SortedBy_X.GetRange(3, 3), true, true);
            row3 = InsertionSort(SortedBy_X.GetRange(6, 3), true, true);


            // Print out Each Row
            Console.Write("Row 1: ");
            foreach (float[] tuple in row1)
                Console.Write(FormatTuple(tuple) + " ");

            Console.WriteLine();

            Console.Write("Row 2: ");
            foreach (float[] tuple in row2)
                Console.Write(FormatTuple(tuple) + " ");

            Console.WriteLine();

            Console.Write("Row 3: ");
            foreach (float[] tuple in row3)
                Console.Write(FormatTuple(tuple) + " ");
        }


        /// <summary>
        /// Sort and Display Cols
        /// </summary>
        private void DisplayColView()
        {
            // Sort entire list of tuples by Y value
            List<float[]> SortedBy_Y = InsertionSort(tuples, true, true);

            // Create 3 buckets to house the rows data, sort the data by Y
            col1 = InsertionSort(SortedBy_Y.GetRange(0, 3), false, false);
            col2 = InsertionSort(SortedBy_Y.GetRange(3, 3), false, false);
            col3 = InsertionSort(SortedBy_Y.GetRange(6, 3), false, false);


            // Print out Each Row
            Console.Write("Col 1: ");
            foreach (float[] tuple in col1)
                Console.Write(FormatTuple(tuple) + " ");

            Console.WriteLine();

            Console.Write("Col 2: ");
            foreach (float[] tuple in col2)
                Console.Write(FormatTuple(tuple) + " ");

            Console.WriteLine();

            Console.Write("Col 3: ");
            foreach (float[] tuple in col3)
                Console.Write(FormatTuple(tuple) + " ");
        }

        /// <summary>
        /// Use points from Row 1 to find the angle between the line and the horizontal Axis (x)(180)
        /// </summary>
        private void DisplayAngleBetween()
        {
            // Slope of the Line on Row 1
            float deltaY = row1[2][1] - row1[0][1];
            float deltaX = row1[2][0] - row1[0][0];

            // Angle between the line and the horizontal axis (180)
            var angleInDegrees = Math.Atan2(deltaY, deltaX) * 180 / Math.PI;

            // Print Angle Between
            Console.WriteLine("Alpha: " + angleInDegrees + " degrees");
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Public Method to Display Formatted Data
        /// </summary>
        public void DisplayData()
        {
            // Print Title
            Console.Write("Grid Test Demo \n \n");
            // Print Row
            DisplayRowView();
            Console.WriteLine("\n \n");
            // Print Col
            DisplayColView();
            Console.WriteLine("\n");
            DisplayAngleBetween();
            // Suspend Application
            Console.ReadKey();
        }

        #endregion 

    }
}

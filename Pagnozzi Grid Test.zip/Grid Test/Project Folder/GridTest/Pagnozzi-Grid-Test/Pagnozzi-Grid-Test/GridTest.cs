﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


// NOTES
/*********************************************************************************************************************************/
// If you aren't passing the text file through args, you can use the                                                             //                 
// below paths instead. I've added both the example_input and the grid_input                                                     //
// text files inside the AppDomain (bin->debug) folder inside the project                                                        //
//                                                                                                                               //
//      I used  "C:\\Projects\\Grid-Test\\GridTest\\Pagnozzi-Grid-Test\\Pagnozzi-Grid-Test\\bin\\Debug/grid_input.txt"           //
//      as command line arguement inside visual studio debug. It only worked with the double '\\'                                //
/*********************************************************************************************************************************/


namespace Pagnozzi_Grid_Test
{
    class GridTest
    {
        static void Main(string[] args)
        {  
            string filePath;  // String to hold the path to our text file

            if (args == null || args.Length == 0)
            {
                //filePath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory) + "/grid_input.txt"; // Uncomment to use Actual Test Values
                filePath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory) + "/example.txt";  // Uncomment to use Example Values
            }
            else
            {
                filePath = args[0];
            }
         
            GridController gridController = new GridController(filePath); // Create Instance of our GridController
        
            gridController.DisplayData();// Display our Data in the Console Window

        }
    }
     

}









